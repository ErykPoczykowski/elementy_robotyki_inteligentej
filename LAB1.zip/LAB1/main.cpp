#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

int main()
{
    // rozmiar tablicy
    const int Xsize = 20;
    const int Ysize = 20;
    // tabele u�ywane w programie
    int parent[Xsize][Ysize] = {0};
    float heuristic[Xsize][Ysize] = {0};
    int Ycoordinates[Xsize][Ysize] = {0};
    int grid[Xsize][Ysize];
    // otworzenie pliku
    ifstream plik("grid.txt");
    // zczytywanie warto�ci z pliku do tabeli
    for (int i = 0; i < Xsize; ++i)
    {
        for (int j = 0; j < Ysize; ++j)
        {
            plik >> grid[j][i];
        }
    }
    // zamkni�cie pliku
    plik.close();

    // koordynaty startu i celu
    int YCRstart = 0;
    int YCRcel = 19;
    int XCRcel = 19;
    int Xstart = 0;
    int Ystart = 19;
    // startowy punkt oznaczany jest jako 9
    parent[Xstart][Ystart]= 9;
    // tymczasowe warto�ci u�ywane do obliczania d�ugo�ci trasy
    int Xtemp=Xstart;
    int Ytemp=Ystart;
    // warto�� u�ywana do obliczania najmniejszej warto�ci heurestyki
    float Hmin = 1000;
    // d�ugo�� trasy
    int route = 0;
    // sprawdzanie czy istnieje prawid�owa trasa
    bool routeAvailability = false;
    // sprawdzanie czy jest jaka� warto�� heurecystyczna do obliczenia
    bool heuristicAvailability = false;
    // tworzenie tabeli koordynat�w dla Y tak by by�a odwr�cona
    for(int i = 0; i<Xsize;i++)
    {
        for(int j = 0; j<Ysize;j++)
        {
            Ycoordinates[Ysize-1-j][i] = Ysize - i-1;
        }

    }
    // info
    cout<<"--------- info o gridzie --------"<<endl;
    cout<<"---------------------------------"<<endl;
    cout<<"1:  zamkniete,       2: otwarte "<<endl;
    cout<<"5: przeszkody, 7: skonczona trasa"<<endl;
    // g��wny algorytm

    int k = 0; // test
    while(true)
    {
        heuristicAvailability = false;
        routeAvailability = false;
        Xtemp=Xstart;
        Ytemp=Ystart;
        // aktualny punkt zaznaczany jest jako 1 = zamkni�ty
        grid[Xstart][Ystart]= 1;
        // sprawdzanie czy aktualny punkt to cel
        if(Xstart == XCRcel && YCRstart == YCRcel)
        {
            heuristicAvailability = true;
            routeAvailability = true;
            cout <<"route length: "<< route << endl;
            break;
        }

        // sprawdzanie czy punkty obok s� prawid�owymi celami do ekspansji
        if(grid[Xstart][Ystart-1] != 5 && Ystart > 0)
        {
            //zaznaczanie trasy jako prawid�owej
            routeAvailability = true;
            if(grid[Xstart][Ystart-1] != 1)
            {
                // zaznaczanie jako 2 = otwarty
                grid[Xstart][Ystart-1] = 2;
                // zaznaczanie orientacji rodzica tego punktu
                parent[Xstart][Ystart-1] = 2;
                // sprawdzanie czy heurestyka by�a ju� obliczana dla tego punktu
                if(heuristic[Xstart][Ystart-1] == 0)
                {
                    // kalkulacja heurystyki
                    heuristic[Xstart][Ystart-1] = route + 1 + round(sqrt(pow(Xstart - XCRcel,2)+(pow(YCRstart+1-YCRcel,2)))*100)/100;
                }
            }
        }

        if(grid[Xstart][Ystart+1] != 5 && Ystart < Ysize-1)
        {
            routeAvailability = true;
            if(grid[Xstart][Ystart+1] != 1)
            {
                grid[Xstart][Ystart+1] = 2;
                parent[Xstart][Ystart+1] = 1;
                if(heuristic[Xstart][Ystart+1] == 0)
                {
                    heuristic[Xstart][Ystart+1] = route + 1 + round(sqrt(pow(Xstart - XCRcel,2)+(pow(YCRstart-1-YCRcel,2)))*100)/100;
                }
            }
        }

        if(grid[Xstart-1][Ystart] != 5 && Xstart > 0)
        {
            routeAvailability = true;
            if(grid[Xstart-1][Ystart] != 1)
            {

                grid[Xstart-1][Ystart] = 2;
                parent[Xstart-1][Ystart] = 4;
                if(heuristic[Xstart-1][Ystart] == 0)
                {
                    heuristic[Xstart-1][Ystart] = route + 1 + round(sqrt(pow(Xstart-1 - XCRcel,2)+(pow(YCRstart-YCRcel,2)))*100)/100;
                }
            }
        }

        if(grid[Xstart+1][Ystart] != 5 && Xstart < Xsize-1)
        {
            routeAvailability = true;
            if(grid[Xstart+1][Ystart] != 1)
            {
                grid[Xstart+1][Ystart] = 2;
                parent[Xstart+1][Ystart] = 3;
                if(heuristic[Xstart+1][Ystart] == 0)
                {
                    heuristic[Xstart+1][Ystart] = route + 1 + round(sqrt(pow(Xstart+1 - XCRcel,2)+(pow(YCRstart-YCRcel,2)))*100)/100;
                }
            }
        }
        // szukanie punktu z najmniejsz� heurestyk� z zbioru punkt�w otwartych
        Hmin = 1000;
        for(int i = 0; i<Xsize;i++)
        {
            for(int j = 0; j<Ysize;j++)
            {
                if(heuristic[j][i] > 0 && heuristic[j][i] <= Hmin && grid[j][i]!= 1)
                {
                    // zaznaczenie ze jest punkt kt�ry mozna jeszcze obliczyc
                    heuristicAvailability = true;
                    // zapamietanie punktu z najmniejsza wartoscia heurecystyczna
                    Hmin = heuristic[j][i];
                    Xstart = j;
                    Ystart = i;
                    YCRstart = Ycoordinates[j][i];
                }
            }
        }
        // sprawdzanie czy istnieje trasa do celu
        if(heuristicAvailability == false || routeAvailability == false)
        {
            cout <<"Cel jest niemozliwy do osiagniecia!"<<endl;
            break;
        }

        Xtemp = Xstart;
        Ytemp = Ystart;
        route = 0;

        // obliczanie dlugosci trasy od startu do aktualnego punktu przy u�yciu tabeli parent
        while(true)
        {
            if(parent[Xtemp][Ytemp]==1 && parent[Xtemp][Ytemp]!=9)
            {
                route++;
                Ytemp--;
            }
            else if(parent[Xtemp][Ytemp]==2 && parent[Xtemp][Ytemp]!=9)
            {
                route++;
                Ytemp++;
            }
            else if(parent[Xtemp][Ytemp]==3 && parent[Xtemp][Ytemp]!=9)
            {
                route++;
                Xtemp--;
            }
            else if(parent[Xtemp][Ytemp]==4 && parent[Xtemp][Ytemp]!=9)
            {
                route++;
                Xtemp++;
            }
            else
            {
                break;
            }
        }
        k++;
    }

    // wizualizacja na gridzie trasy znalezionej przez algorytm za pomoc� liczby 7
    while(heuristicAvailability == true && routeAvailability == true)
    {
        grid[Xtemp][Ytemp] = 7;
        if(parent[Xtemp][Ytemp]==1 && parent[Xtemp][Ytemp]!=9)
        {
            route++;
            Ytemp--;
        }
        else if(parent[Xtemp][Ytemp]==2 && parent[Xtemp][Ytemp]!=9)
        {
            route++;
            Ytemp++;
        }
        else if(parent[Xtemp][Ytemp]==3 && parent[Xtemp][Ytemp]!=9)
        {
            route++;
            Xtemp--;
        }
        else if(parent[Xtemp][Ytemp]==4 && parent[Xtemp][Ytemp]!=9)
        {
            route++;
            Xtemp++;
        }
        else
        {
            break;
        }
    }

    // wizualizacja gridu
    cout<<"----------------grid-----------------"<<endl;
    for(int i = 0; i<Xsize;i++)
    {
        for(int j = 0; j<Ysize;j++)
        {
            cout << grid[j][i]<<"|";
        }
        cout <<endl;
    }
    // wizualizacja reszty tabel dla testowania
    cout<<"--------------heuristic--------------"<<endl;
    for(int i = 0; i<Xsize;i++)
    {
        for(int j = 0; j<Ysize;j++)
        {
            cout << heuristic[j][i]<<"|";
        }
        cout <<endl;
    }
    cout<<"----------------parent---------------"<<endl;
    for(int i = 0; i<Xsize;i++)
    {
        for(int j = 0; j<Ysize;j++)
        {
            cout << parent[j][i]<<"|";
        }
        cout <<endl;
    }
    cout<<"----------------Ycoordinates---------------"<<endl;
    for(int i = 0; i<Xsize;i++)
    {
        for(int j = 0; j<Ysize;j++)
        {
            cout << Ycoordinates[j][i]<<"|";
        }
        cout <<endl;
    }
    return 0;

}

