#include <iostream>

using namespace std;

//-------------------------------------- filtr 1d -----------------------------------------------//

void filtr(int swiat[], int rozmiar_s,int pomiar[], int rozmiar_p, double dokladnosc_r, double dokladnosc_p)
{
    double lokalizacja[rozmiar_s];
    double suma;

    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacja[i]=1.0/rozmiar_s;
    }
    cout<<"startowa tablica"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;
    for(int k=0;k<rozmiar_p;k++)
    {

    // pomiar
    if(pomiar[k] == 1)
    {
        for(int i = 0;i<rozmiar_s;i++)
        {
            if(swiat[i]==1)
            {
                lokalizacja[i]*=dokladnosc_p;
            }
            else
            {
                lokalizacja[i]*=(1-dokladnosc_p);
            }
        }
    }
    else
    {
        for(int i = 0;i<rozmiar_s;i++)
        {
            if(swiat[i]==1)
            {
                lokalizacja[i]*=(1-dokladnosc_p);
            }
            else
            {
                lokalizacja[i]*=dokladnosc_p;
            }
        }
    }
    cout<<"tablica po pomiarze"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;

    //normalizacja
    suma = 0.0;
    for(int i = 0;i<rozmiar_s;i++)
    {
        suma +=lokalizacja[i];
    }
    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacja[i]/=suma;
    }
    cout<<"tablica po normalizacji"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;

    // ruch tobota
    double lokalizacjaT[rozmiar_s];

    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacjaT[i]=lokalizacja[i];
    }
    for(int i = 0;i<rozmiar_s;i++)
    {
        if(i==0)
        {

            lokalizacja[i]=lokalizacjaT[rozmiar_s-i-1]*dokladnosc_r+lokalizacjaT[rozmiar_s-i-2]*(1-dokladnosc_r);
        }
        else if(i==1)
        {
            lokalizacja[i]=lokalizacjaT[i-1]*dokladnosc_r+lokalizacjaT[rozmiar_s-i]*(1-dokladnosc_r);
        }
        else
        {
            lokalizacja[i]=lokalizacjaT[i-1]*dokladnosc_r+lokalizacjaT[i-2]*(1-dokladnosc_r);
        }

    }
    cout<<"tablica po ruchu"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacjaT[i]=lokalizacja[i];
    }
    cout<<endl;
    cout << "iteracja numer: " <<k+1<< endl;
    cout << "--------------------------------------------------------------"<< endl;
    cout<<endl;
    cout<<endl;
    }
}

int main()
{
    /*
    double dokladnosc_r= 0.9;
    double dokladnosc_p= 0.8;

    int rozmiar_s = 10;
    int rozmiar_p = 10;

    // drzwi - 1, sciana - 2
    int swiat[rozmiar_s] = {2,2,1,1,2,2,2,2,2,1};
    int pomiar[rozmiar_p] = {2,2,1,1};

    filtr(swiat, rozmiar_s, pomiar, rozmiar_p, dokladnosc_r, dokladnosc_p);
    */

     // 1 - biały, 2 - zielony, 3 - czerwony, 4 - czarny
    int swiat[3][5] = {
        {4,3,1,3,2},
        {3,1,2,4,1},
        {1,3,1,3,2}
    };
    int wiersze = sizeof swiat / sizeof swiat[0]; // 2 rows
    int kolumny = sizeof swiat[0] / sizeof(int); // 5 cols
    cout<< wiersze<<"; "<<kolumny;

    double lokalizacja[3][5];
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0; j < kolumny;j++)
        {
            lokalizacja[i][j]=1.0/(wiersze*kolumny);
        }
    }
    cout<<"startowa tablica"<<endl;
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0; j < kolumny;j++)
        {
            cout<<lokalizacja[i][j]<<", ";
        }
        cout<<endl;
    }


    return 0;

}
