#include <iostream>

using namespace std;

void filtr(int swiat[], int rozmiar_s,int pomiar[], int rozmiar_p, double dokladnosc_r, double dokladnosc_p)
{
    double lokalizacja[rozmiar_s];
    double suma;

    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacja[i]=1.0/rozmiar_s;
    }
    cout<<"startowa tablica"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;
    for(int k=0;k<rozmiar_p;k++)
    {

    // pomiar
    if(pomiar[k] == 1)
    {
        for(int i = 0;i<rozmiar_s;i++)
        {
            if(swiat[i]==1)
            {
                lokalizacja[i]*=dokladnosc_p;
            }
            else
            {
                lokalizacja[i]*=(1-dokladnosc_p);
            }
        }
    }
    else
    {
        for(int i = 0;i<rozmiar_s;i++)
        {
            if(swiat[i]==1)
            {
                lokalizacja[i]*=(1-dokladnosc_p);
            }
            else
            {
                lokalizacja[i]*=dokladnosc_p;
            }
        }
    }
    cout<<"tablica po pomiarze"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;

    //normalizacja
    suma = 0.0;
    for(int i = 0;i<rozmiar_s;i++)
    {
        suma +=lokalizacja[i];
    }
    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacja[i]/=suma;
    }
    cout<<"tablica po normalizacji"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    cout<<endl;

    // ruch tobota
    double lokalizacjaT[rozmiar_s];

    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacjaT[i]=lokalizacja[i];
    }
    for(int i = 0;i<rozmiar_s;i++)
    {
        if(i==0)
        {

            lokalizacja[i]=lokalizacjaT[rozmiar_s-i-1]*dokladnosc_r+lokalizacjaT[rozmiar_s-i-2]*(1-dokladnosc_r);
        }
        else if(i==1)
        {
            lokalizacja[i]=lokalizacjaT[i-1]*dokladnosc_r+lokalizacjaT[rozmiar_s-i]*(1-dokladnosc_r);
        }
        else
        {
            lokalizacja[i]=lokalizacjaT[i-1]*dokladnosc_r+lokalizacjaT[i-2]*(1-dokladnosc_r);
        }

    }
    cout<<"tablica po ruchu"<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        cout<<lokalizacja[i]<<", ";
    }
    cout<<endl;
    for(int i = 0;i<rozmiar_s;i++)
    {
        lokalizacjaT[i]=lokalizacja[i];
    }
    cout<<endl;
    cout << "iteracja numer: " <<k+1<< endl;
    cout << "--------------------------------------------------------------"<< endl;
    cout<<endl;
    cout<<endl;
    }
}




int iteracja = 0;
const int wiersze = 3;
const int kolumny = 5;

bool jestPoprawne(int r, int c) {
    return (r >= 0 && r < wiersze && c >= 0 && c < kolumny);
}
void filtr2d(int swiat[wiersze][kolumny], int pomiar,int ruchW, int ruchK, double dokladnosc_r, double dokladnosc_p)
{
    double suma;
    double lokalizacja[3][5];
    // prawdopodobieństwo lokalizacji
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            lokalizacja[i][j] = 1.0/(kolumny*wiersze);
        }
    }
    // wypisanie lokalizacji
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            cout<<lokalizacja[i][j]<<", ";
        }
        cout<<endl;
    }
    // pomiar

    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            if(pomiar == 1 && swiat[i][j]==1)
            {
                lokalizacja[i][j]*=dokladnosc_p;
            }
            else if(pomiar == 3 && swiat[i][j]==3)
            {
                lokalizacja[i][j]*=dokladnosc_p;
            }
            else if(pomiar == 5 && swiat[i][j]==5)
            {
                lokalizacja[i][j]*=dokladnosc_p;
            }
            else if(pomiar == 6 && swiat[i][j]==6)
            {
                lokalizacja[i][j]*=dokladnosc_p;
            }
            else
            {
                lokalizacja[i][j]*=(1-dokladnosc_p);
            }
        }
    }
    cout << endl;
    cout<<"tablica nieznormalizowana"<< endl;
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            cout<<lokalizacja[i][j]<<", ";
        }
        cout<<endl;
    }
    //normalizacja
    suma = 0.0;
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            suma +=lokalizacja[i][j];
        }
    }
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            lokalizacja[i][j]/=suma;
        }
    }
    cout << endl;
    cout<<"tablica po normalizacji"<<endl;
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            cout<<lokalizacja[i][j]<<", ";
        }
        cout<<endl;
    }
    cout<<endl;
    double lokalizacjaT[3][5];
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            lokalizacjaT[i][j]=0.0;
        }
    }
    // obługa ruchu
    for(int i = 0;i<wiersze;++i)
    {
        for(int j = 0;j<kolumny;++j)
        {
            double szansa = lokalizacja[i][j];

            int celW = i + ruchW;
            int celK = j + ruchK;
            // sprawdzenie czy nie wyjeżdżamy poza pole, w przypadku wyjazdu następuje odbicie
            if(!jestPoprawne(celW,celK))
            {
                  celW = i;
                  celK = j;
            }
            // szansa na poruszenie się w daną strone
            lokalizacjaT[celW][celK] += szansa * dokladnosc_r;
            //obliczanie poprawnych sąsiadów (ignorujemy ściany)
            int iloscSasiadow = 0;
            int coordSasiadow[4][2];
            int coordkierunkow[4][2]={{-1,0}, {1,0}, {0,-1}, {0,1}};

            for(int k = 0;k < 4;++k)
            {
                // obliczanie koordynatów danego sąsiada
                int sasiadW = celW + coordkierunkow[k][0];
                int sasiadK = celK + coordkierunkow[k][1];
                // sprawdzenie czy jets on poprawnym celem
                if(jestPoprawne(sasiadW,sasiadK))
                {
                    // zapisanie go do koordynatów i zwiększenie ilości sąsiadów o 1
                    coordSasiadow[iloscSasiadow][0] = sasiadW;
                    coordSasiadow[iloscSasiadow][1] = sasiadK;
                    iloscSasiadow++;
                }
            }
            // jeśli jest przynajmniej 1 poprawny sąsiad
            if (iloscSasiadow > 0)
            {
                // obliczamy prawdopodobieństwo dla sąsiadów zależne od tego ile ich jest
                double sasiadP = (szansa * (1-dokladnosc_r)) / iloscSasiadow ;

                for(int l = 0; l < iloscSasiadow; l++)
                {
                    // dodanie prawdopodobieństwa do pól poprawnych sąsiadów
                    int sasiadW = coordSasiadow[l][0];
                    int sasiadK = coordSasiadow[l][1];
                    lokalizacjaT[sasiadW][sasiadK] += sasiadP;
                }
            }
        }
    }
    // przepisanie wyników z tablicy tymczasowej do orginalnej
    for(int i = 0; i < wiersze; ++i)
    {
        for(int j = 0; j < kolumny; ++j)
        {
            lokalizacja[i][j] = lokalizacjaT[i][j];
        }
    }
    // wyświetlenie tablicy
    cout<<"tablica po ruchu w gore"<<endl;
    for(int i = 0;i<wiersze;i++)
    {
        for(int j = 0;j<kolumny;j++)
        {
            cout<<lokalizacja[i][j]<<", ";
        }
        cout<<endl;
    }
    cout<<endl<<"koniec ruchu!"<<endl;
}

int main()
{
    /*double dokladnosc_r= 0.9;
    double dokladnosc_p= 0.8;

    int rozmiar_s = 10;
    int rozmiar_p = 5;

    // drzwi - 1, œciana - 2
    int swiat[rozmiar_s] = {2,2,1,1,2,2,2,2,2,1};
    int pomiar[rozmiar_p] = {2,2,2,2,2};

    filtr(swiat, rozmiar_s, pomiar, rozmiar_p, dokladnosc_r, dokladnosc_p);
    */
    // filtr 2d
    // czarny = 1, zielony = 3, czerowny = 5, biały = 6
    // ruch w góre
    int ruchW = -1;
    int ruchK = 0;
    // pomiar koloru
    int pomiar = 6;
    double dokladnosc_r= 0.6;
    double dokladnosc_p= 0.8;
    int swiat[3][5]={{1,5,6,5,3},
                     {5,6,3,1,6},
                     {6,5,6,5,3}};

    filtr2d(swiat,pomiar,ruchW,ruchK,dokladnosc_r,dokladnosc_p);

    return 0;
}
