import os
import random
import platform
import collections

# --- Sekcja obsługi wejścia i czyszczenia ekranu (bez zmian) ---
try:
    import msvcrt


    def get_key_press():
        return msvcrt.getch().decode('utf-8').lower()
except ImportError:
    import tty, sys, termios


    def get_key_press():
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch.lower()


def clear_screen():
    os.system('cls' if platform.system() == 'Windows' else 'clear')


# --- Klasa Node i algorytm A* (bez zmian) ---
class Node():
    def __init__(self, parent=None, position=None):
        self.parent, self.position, self.g, self.h, self.f = parent, position, 0, 0, 0

    def __eq__(self, other): return self.position == other.position


def astar_pathfinding(maze, start, end):
    start_node, end_node = Node(None, start), Node(None, end)
    open_list, closed_list = [start_node], []
    while open_list:
        current_node = min(open_list, key=lambda o: o.f)
        open_list.remove(current_node)
        closed_list.append(current_node)
        if current_node == end_node:
            path = []
            current = current_node
            while current: path.append(current.position); current = current.parent
            return path[::-1]
        children = []
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            node_position = (current_node.position[0] + new_position[0], current_node.position[1] + new_position[1])
            if not (0 <= node_position[0] < len(maze) and 0 <= node_position[1] < len(maze[0])) or \
                    maze[node_position[0]][node_position[1]] != 0: continue
            children.append(Node(current_node, node_position))
        for child in children:
            if child in closed_list: continue
            child.g = current_node.g + 1
            child.h = abs(child.position[0] - end_node.position[0]) + abs(child.position[1] - end_node.position[1])
            child.f = child.g + child.h
            if any(open_node for open_node in open_list if child == open_node and child.g >= open_node.g): continue
            open_list.append(child)
    return None


class Enemy:
    def __init__(self, position):
        self.position = position
        self.status = "Rozpoczynam patrol..."
        self.last_known_player_pos = None
        self.long_term_target = None
        self.idle_turn_counter = 0
        self.move_counter = 0
        self.stun_timer = 0


# --- Funkcje pomocnicze gry (bez zmian) ---
def generate_maze(width, height, loop_chance=0.15):
    w, h = (width // 2) * 2 + 1, (height // 2) * 2 + 1
    maze = [['#' for _ in range(w)] for _ in range(h)]

    def carve_passages(cx, cy):
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        random.shuffle(directions)
        for dx, dy in directions:
            nx, ny = cx + dx * 2, cy + dy * 2
            if 1 <= ny < h - 1 and 1 <= nx < w - 1 and maze[ny][nx] == '#':
                maze[cy + dy][cx + dx] = ' ';
                maze[ny][nx] = ' ';
                carve_passages(nx, ny)

    start_x, start_y = random.randint(0, w // 2 - 1) * 2 + 1, random.randint(0, h // 2 - 1) * 2 + 1
    maze[start_y][start_x] = ' ';
    carve_passages(start_x, start_y)
    for r in range(1, h - 1):
        for c in range(1, w - 1):
            if maze[r][c] == '#' and random.random() < loop_chance:
                is_h_wall, is_v_wall = maze[r][c - 1] == ' ' and maze[r][c + 1] == ' ', maze[r - 1][c] == ' ' and \
                                       maze[r + 1][c] == ' '
                if is_h_wall or is_v_wall: maze[r][c] = ' '
    exit_pos = (h - 2, w - 2);
    maze[exit_pos[0]][exit_pos[1]] = 'W'
    return maze, exit_pos


def print_game_state(maze, player_pos, enemies, endgame_active=False):
    display_maze = [list(row) for row in maze]
    display_maze[player_pos[0]][player_pos[1]] = 'P'
    for enemy in enemies:
        if enemy.position: display_maze[enemy.position[0]][enemy.position[1]] = 'E'
    clear_screen()
    title = "--- UCIEKAJ Z LABIRYNTU! (Wersja 8.1: Finał) ---"
    print(title)
    if endgame_active:
        print("### ALARM! JESTEŚ BLISKO WYJŚCIA! WROGOWIE CIĘ NAMIERZYLI! ###")
    else:
        print("Sterowanie: W, A, S, D | Q = Wyjdź")
    for i, enemy in enumerate(enemies):
        print(f"Status wroga {i + 1}: {enemy.status}")
    print("-" * len(title))
    for row in display_maze:
        print(' '.join(row))
    print("-" * len(title))


def znajdz_cel_w_odleglosci(maze, start_pos, distance):
    q = collections.deque([(start_pos, 0)]);
    visited = {start_pos};
    targets = []
    while q:
        (r, c), dist = q.popleft()
        if dist >= distance: continue
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < len(maze) and 0 <= nc < len(maze[0]) and maze[nr][nc] == 0 and (nr, nc) not in visited:
                visited.add((nr, nc))
                if dist + 1 == distance: targets.append((nr, nc))
                q.append(((nr, nc), dist + 1))
    if targets: return random.choice(targets)
    return None


# --- Główna pętla gry ---
def main_game_loop():
    MAZE_WIDTH, MAZE_HEIGHT = 31, 31
    TRACKING_RANGE, IDLE_TURNS_BEFORE_SEARCH, MOVES_BEFORE_STUN = 8, 8, 5

    # === ZMIANA ZNAJDUJE SIĘ TUTAJ ===
    ENDGAME_DISTANCE = 16
    # ================================

    while True:
        maze_layout, exit_pos = generate_maze(MAZE_WIDTH, MAZE_HEIGHT)
        player_pos = (1, 1)
        center_pos = (MAZE_HEIGHT // 2, MAZE_WIDTH // 2)
        if maze_layout[center_pos[0]][center_pos[1]] == '#':
            maze_layout[center_pos[0]][center_pos[1]] = ' '

        enemies = [Enemy(position=center_pos) for _ in range(3)]
        game_over, win_message = False, ""

        while not game_over:
            distance_to_exit = abs(player_pos[0] - exit_pos[0]) + abs(player_pos[1] - exit_pos[1])
            is_endgame_mode = distance_to_exit <= ENDGAME_DISTANCE

            print_game_state(maze_layout, player_pos, enemies, is_endgame_mode)

            move = get_key_press()
            if move == 'q': print("Dzięki za grę!"); return
            r, c = player_pos;
            new_pos = player_pos
            if move == 'w':
                new_pos = (r - 1, c)
            elif move == 's':
                new_pos = (r + 1, c)
            elif move == 'a':
                new_pos = (r, c - 1)
            elif move == 'd':
                new_pos = (r, c + 1)
            if 0 <= new_pos[0] < len(maze_layout) and 0 <= new_pos[1] < len(maze_layout[0]) and maze_layout[new_pos[0]][
                new_pos[1]] != '#':
                player_pos = new_pos

            if player_pos in [e.position for e in enemies]:
                game_over, win_message = True, "❌ Zostałeś złapany! KONIEC GRY. ❌"
            elif player_pos == exit_pos:
                game_over, win_message = True, "🏆 Gratulacje! Uciekłeś z labiryntu! 🏆"
            if game_over: break

            maze_numeric = [[0 if cell != '#' else 1 for cell in row] for row in maze_layout]
            for enemy in enemies:
                if is_endgame_mode:
                    enemy.status = "GRACZ JEST BLISKO CELU, POWSTRZYMAĆ GO!"
                    path = astar_pathfinding(maze_numeric, enemy.position, player_pos)
                    if path and len(path) > 1:
                        enemy.position = path[1]
                else:
                    if enemy.stun_timer > 0:
                        enemy.status, enemy.stun_timer = "Odpoczywam...", enemy.stun_timer - 1
                        continue
                    target_pos, is_chasing = None, False
                    is_player_in_range = abs(player_pos[0] - enemy.position[0]) <= TRACKING_RANGE and abs(
                        player_pos[1] - enemy.position[1]) <= TRACKING_RANGE

                    if is_player_in_range:
                        enemy.status, enemy.last_known_player_pos, enemy.long_term_target, enemy.idle_turn_counter = "Wykryto gracza! Gnam!", player_pos, None, 0
                        target_pos, is_chasing = player_pos, True
                    else:
                        enemy.idle_turn_counter += 1
                        if enemy.last_known_player_pos:
                            enemy.status, target_pos, is_chasing = "Idę do ostatniej znanej pozycji...", enemy.last_known_player_pos, True
                            if enemy.position == enemy.last_known_player_pos: enemy.last_known_player_pos, enemy.move_counter = None, 0
                        elif enemy.long_term_target:
                            enemy.status, target_pos, enemy.move_counter = "Sprawdzam podejrzany obszar...", enemy.long_term_target, 0
                            if enemy.position == enemy.long_term_target: enemy.long_term_target, enemy.idle_turn_counter = None, 0
                        elif enemy.idle_turn_counter >= IDLE_TURNS_BEFORE_SEARCH:
                            enemy.status, enemy.idle_turn_counter, enemy.move_counter = "Zbyt cicho... Szukam w nowym miejscu.", 0, 0
                            new_target = znajdz_cel_w_odleglosci(maze_numeric, enemy.position, 10)
                            if new_target: enemy.long_term_target, target_pos = new_target, new_target
                        else:
                            enemy.status, enemy.move_counter = "Patroluję teren...", 0
                    if target_pos:
                        path = astar_pathfinding(maze_numeric, enemy.position, target_pos)
                        if path and len(path) > 1:
                            enemy.position = path[1]
                            if is_chasing:
                                enemy.move_counter += 1
                                if enemy.move_counter >= MOVES_BEFORE_STUN:
                                    enemy.move_counter, enemy.stun_timer = 0, 1
                    else:
                        r, c = enemy.position
                        possible_moves = [(r + dr, c + dc) for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)] if
                                          maze_layout[r + dr][c + dc] != '#']
                        if possible_moves: enemy.position = random.choice(possible_moves)

            if player_pos in [e.position for e in enemies]:
                game_over, win_message = True, "❌ Zostałeś złapany! KONIEC GRY. ❌"

        print_game_state(maze_layout, player_pos, enemies, game_over)
        print(win_message)
        if input("\nCzy chcesz zagrać jeszcze raz? (t/n): ").lower() != 't':
            print("Do zobaczenia! 👋");
            break


if __name__ == '__main__':
    main_game_loop()